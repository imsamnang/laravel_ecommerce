	jQuery(document).ready(function($) {
	  
	  
 $("#edit-field-series1-und-0-value").remoteChained({
    parents : "#edit-field-marka1-und-0-value",
    url : "/sites/all/libraries/chained_selects/json.php?sleep=1",
        loading : "--"
});
 });