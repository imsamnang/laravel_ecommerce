<?php

/* This is just a dummy file for generating example JSON. */

/* Emulate slow queries when asked. */
if (isset($_GET["sleep"])) {
    sleep(1);
}
 
header("Access-Control-Allow-Origin: *");

$response[""] = "--";

if (isset($_GET["series"]) && isset($_GET["model"])) {

  $response[""] = "--";

  

} else if (isset($_GET["edit-field-marka1-und-0-value"])) {
    if ("bmw" == $_GET["edit-field-marka1-und-0-value"]) {
        $response[""] = "--";
        $response["series-1"] = "1 series";
        $response["series-3"] = "3 series";
        $response["series-5"] = "5 series";
        $response["series-6"] = "6 series";
        $response["series-7"] = "7 series";
    };

    if ("audi" == $_GET["edit-field-marka1-und-0-value"]) {
        $response[""] = "--";
        $response["a1"]  = "A1";
        $response["a3"]  = "A3";
        $response["s3"]  = "S3";
        $response["a4"]  = "A4";
        $response["s4"]  = "S4";
        $response["a5"]  = "A5";
        $response["s5"]  = "S5";
        $response["a6"]  = "A6";
        $response["s6"]  = "S6";
        $response["rs6"] = "RS6";
        $response["a8"]  = "A8";
    };
} 

print json_encode($response);
