    var input = document.getElementById('edit-field-marka1-und-0-value'),
        parent = input.parentNode,
        select = document.createElement('SELECT');
      
    select.id = input.id;
    select.name = input.name;
	select.options[0] = new Option('--','') ;
    select.options[1] = new Option('BMW','bmw') ;
    select.options[2] = new Option('Audi','audi');
      
    parent.insertBefore(select, input);
    parent.removeChild(input);

    var input = document.getElementById('edit-field-series1-und-0-value'),
        parent = input.parentNode,
        select = document.createElement('SELECT');
      
    select.id = input.id;
    select.name = input.name;
    select.options[0] = new Option('--','') ;
       
    parent.insertBefore(select, input);
    parent.removeChild(input);
	
	
 