<script>
$('#myPopover').on('hidden.bs.popover', function () {
  // do something…
})
</script>