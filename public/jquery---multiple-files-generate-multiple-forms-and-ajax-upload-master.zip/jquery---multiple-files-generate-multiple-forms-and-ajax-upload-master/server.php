<?php

	var_dump($_FILES); //files

	var_dump($_POST); //post

 ?>