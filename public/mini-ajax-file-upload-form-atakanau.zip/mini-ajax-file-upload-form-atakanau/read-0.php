<?php
header('Content-Type: application/json');

$file_dir = 'uploads/0/';

// A list of permitted file extensions
$allowed = array('png', 'jpg', 'gif','zip');

$allfiles = scandir($file_dir);

$data = array();
foreach($allfiles as $file){
	if($file === '.' || $file === '..')
		continue;

	$extension = pathinfo($file, PATHINFO_EXTENSION);

	if(in_array(strtolower($extension), $allowed)){
		$files[] = [
			 'name' => $file
			,'path' => $file_dir.$file
			,'size' => filesize($file_dir.$file)
		];
	}

} 

echo json_encode(['files' => $files]);
exit;