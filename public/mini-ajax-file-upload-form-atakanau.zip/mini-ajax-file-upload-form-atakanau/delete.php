<?php
header('Content-Type: application/json');

$file = isset($_GET['file']) ? $_GET['file'] : false;

if($file && is_file($file) ){

	if(unlink($file)){
		echo  json_encode([
			 'status' => 'success'
			,'process' => 'delete'
		]);
		exit;
	}
	
}

echo  json_encode([
	 'status' => 'error'
	,'process' => 'delete'
]);
