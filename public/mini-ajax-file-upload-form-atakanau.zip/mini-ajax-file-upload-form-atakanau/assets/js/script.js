$(function(){

	$('a', '.miniafu-drop').each(function(i,e){
		$(e).click(function(){
			// Simulate a click on the file input button
			// to show the file browser dialog
			$(this).parent().find('input').click();
		});
	});

	$('.miniafu-upload').each(function(i,e_upload){
		// Initialize the jQuery File Upload plugin
		$(e_upload).fileupload({

			// This element will accept file drag/drop uploading
			dropZone: $(e_upload).find('.miniafu-drop:first'),

			// This function is called when a file is added to the queue;
			// either via the browse button, or via drag/drop:
			add: function (e, data) {
				var tpl= get_tpl();

				// Append the file name and file size
				tpl.find('p').append('<b>' + data.files[0].name + '</b>')
							 .append('<i>' + filesize(data.files[0].size).human() + '</i>');

				// Add the HTML to the UL element
				data.context = tpl.appendTo( $('ul', e_upload) );

				// Initialize the knob plugin
				tpl.find('input').knob();

				// Listen for clicks on the cancel or delete icon
				tpl.find('span:first').click(function(){

					if(tpl.hasClass('working')){// cancel upload
						jqXHR.abort();

						tpl.fadeOut(function(){
							tpl.remove();
						});
					}
					else if(tpl.hasClass('uploaded')){// delete file
						delete_file(this);
					}

				});

				// Automatically upload the file once it is added to the queue
				var jqXHR = data.submit();
			},

			progress: function(e, data){

				// Calculate the completion percentage of the upload
				var progress = parseInt(data.loaded / data.total * 100, 10);

				// Update the hidden input field and trigger a change
				// so that the jQuery knob plugin knows to update the dial
				data.context.find('input').val(progress).change();

				if(progress == 100){
					data.context.removeClass('working');
				}
			},

			fail:function(e, data){
				// Something has gone wrong!
				data.context.addClass('error');
			},
			done: function(e, data) {
				var r = data.result;

				if(r.process=='upload'){
					if(r.status=='error'){
						data.context.remove();

						// draw red circle start
						var tpl = $('<li class="working error"><input type="text" value="100" data-width="48" data-height="48"'+
							' data-fgColor="#CC0000" data-readOnly="1" data-bgColor="#3e4043" /><p></p><span></span></li>');

						// Append the file name and file size
						tpl.find('p').append('<b>' + data.files[0].name + '</b>')
									 .append('<i>' + r.error + '</i>');

						// Add the HTML to the UL element
						data.context = tpl.appendTo( $('ul', e_upload) );

						// Initialize the knob plugin
						tpl.find('input').knob();

						// Listen for clicks on the cancel icon
						tpl.find('span:first').click(function(){

							tpl.fadeOut(function(){
								tpl.remove();
							});

						});
						// draw red circle end
					}
					else if(r.status=='success'){
						// replace knob with image preview
						data.context.find('canvas').remove();
						data.context.find('input').after( get_img( data.result.path , data.result.path ) ).remove();
						
						// store file path for delete action
						data.context.find('span:first').data('filepath', data.result.path)
						
						// remove name of file from list if already exist
						$("b").filter(function() {
							return $(this).text() === data.result.name;
						}).parents("li.uploaded:first").remove();
						
						// mark file as uploaded
						data.context.addClass('uploaded')
					}
				}

			}

		});
		
		// get already uploaded file list
		$.getJSON( $(e_upload).data('readdir') , function(data) {

			for(var i in data.files){
				
				var tpl= get_tpl();
				tpl.removeClass('working').addClass('uploaded');

				// Append the file name and file size
				tpl.find('p').append('<b>' + data.files[i].name + '</b>')
							 .append('<i>' + filesize(data.files[i].size).human() + '</i>');

				// Add the HTML to the UL element
				data.context = tpl.appendTo( $('ul', e_upload) );

				// replace knob with image preview
				tpl.find('input').after( get_img( data.files[i].path , data.files[i].path ) ).remove();

				// Listen for clicks on the delete icon
				tpl.find('span:first').data('filepath', data.files[i].path).click(function(){
					delete_file(this);
				});

			}
		});
	});

	// Prevent the default action when a file is dropped on the window
	$(document).on('drop dragover', function (e) {
		e.preventDefault();
	});

	// get default file line
	function get_tpl() {
		return $('<li class="working"><input type="text" value="0" data-width="48" data-height="48"'+
		' data-fgColor="#0788a5" data-readOnly="1" data-bgColor="#3e4043" /><p></p><span><span></span></span></li>');
	}

	function get_img(href , src) {
		return $('<a href="'+href+'" target="_blank"><img src="'+src+'" width="65px"></a>');
	}

	function delete_file(button) {
		var li = $(button).parents('li:first')
		, delete_url = $(button).parents('form:first').data('delfile');
		
		$.getJSON( delete_url 
			,{
				file: $(button).data('filepath')
			}
			,function(r) {
				if(r.status == "success")
					li.fadeOut(function(){
						li.remove();
					});
			}
		);

	}

});