<?php
header('Content-Type: application/json');

$file_dir = 'uploads/0/';

// A list of permitted file extensions
$allowed = array('png', 'jpg', 'gif','zip');

if(isset($_FILES['upl']) && $_FILES['upl']['error'] == 0){

	$extension = pathinfo($_FILES['upl']['name'], PATHINFO_EXTENSION);

	if(!in_array(strtolower($extension), $allowed)){
		echo  json_encode([
			 'status' => 'error'
			,'process' => 'upload'
			,'error' => 'not allowed'
		]);
		exit;
	}
	$file = $_FILES['upl']['name'];//	can be a new filename

	if(move_uploaded_file($_FILES['upl']['tmp_name'], $file_dir.$file)){
		echo  json_encode([
			 'status' => 'success'
			,'process' => 'upload'
			,'name' => $file
			,'path' => $file_dir.$file
			,'size' => filesize($file_dir.$file)
		]);
		exit;
	}
}

echo '{"status":"error"}';
exit;